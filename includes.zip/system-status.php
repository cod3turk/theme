<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** ---------------------------------------------------------------------------
 * Server Status
 * @version 1.0
 * ---------------------------------------------------------------------------- */
class cturkServerStatus {

	public $error	= '';
	
	
	/** ---------------------------------------------------------------------------
	 * Constructor
	 * ---------------------------------------------------------------------------- */
	function __construct() {
		add_action( 'admin_menu', array( &$this, 'init' ) );
	}
	
	
	/** ---------------------------------------------------------------------------
	 * Add theme Page
	 * ---------------------------------------------------------------------------- */
	function init() {
		
		$title = esc_html__( 'System Status','ct-theme' );
		
		if( WHITE_LABEL ){
			
			// White Label | Hide 'Server Status' Page
			add_theme_page(
				$title,
				$title,
				'edit_theme_options',
				'ct_theme_status',
				array( &$this, 'server_white' )
			);
			
		} else {
			
			add_theme_page(
				$title,
				$title,
				'edit_theme_options',
				'ct_theme_status',
				array( &$this, 'server' )
			);
			
		}

	}
	
	
	/** ---------------------------------------------------------------------------
	 * White Label | Hide 'Server Status' Page
	 * ---------------------------------------------------------------------------- */
	function server_white() {
		?>
			<div id="ct-theme-wrapper" class="ct-theme-server wrap">
				<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>
				<p><?php esc_html_e( 'This feature is disabled in White Label mode', 'ct-theme' );?></p>
			</div>
		<?php 
	}
	
	
	/** ---------------------------------------------------------------------------
	 * Transforms the php.ini notation for numbers (like '2M') to an integer
	 * ---------------------------------------------------------------------------- */
	function let_to_num( $size ) {
		$l		= substr( $size, -1 );
		$ret	= substr( $size, 0, -1 );
		switch( strtoupper( $l ) ) {
			case 'P':
				$ret *= 1024;
			case 'T':
				$ret *= 1024;
			case 'G':
				$ret *= 1024;
			case 'M':
				$ret *= 1024;
			case 'K':
				$ret *= 1024;
		}
		return $ret;
	}
	
	
	/** ---------------------------------------------------------------------------
	 * Server Status
	 * ---------------------------------------------------------------------------- */
	function server(){
	?>
	
		<div id="ct-theme-wrapper" class="ct-theme-server wrap">
		
			<h2><?php echo esc_html( get_admin_page_title() ); ?></h2>
			
			
			<table class="widefat" cellspacing="0">
			
				<thead>
					<tr>
						<th colspan="3" data-export-label="WordPress Environment"><?php esc_html_e( 'WordPress Environment', 'ct-theme' ); ?></th>
					</tr>
				</thead>
				
				<tbody>
				
					<tr>
						<td data-export-label="Home URL"><?php esc_html_e( 'Home URL', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The URL of your site\'s homepage.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php form_option( 'home' ); ?></td>
					</tr>
					
					<tr>
						<td data-export-label="Site URL"><?php esc_html_e( 'Site URL', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The root URL of your site.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php form_option( 'siteurl' ); ?></td>
					</tr>
					
					<tr>
						<td data-export-label="WP Version"><?php esc_html_e( 'WP Version', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of WordPress installed on your site.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php bloginfo('version'); ?></td>
					</tr>
					
					<tr>
						<td data-export-label="WP Multisite"><?php esc_html_e( 'WP Multisite', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Whether or not you have WordPress Multisite enabled.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php if ( is_multisite() ) echo '&#10004;'; else echo '&ndash;'; ?></td>
					</tr>
					
					<tr>
						<td data-export-label="WP Memory Limit"><?php esc_html_e( 'WP Memory Limit', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum amount of memory (RAM) that your site can use at one time.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php
							$memory = $this->let_to_num( WP_MEMORY_LIMIT );
							
							if( function_exists( 'memory_get_usage' ) ) {
								$server_memory = $this->let_to_num( @ini_get( 'memory_limit' ) );
								$memory = max( $memory, $server_memory );
							}
			
							if ( $memory < 134217728 ) {
								echo '<mark class="error">' . sprintf( wp_kses(__( '%s - We recommend setting memory to at least 128MB. See: <a href="%s" target="_blank">Increasing memory allocated to PHP</a>', 'ct-theme' ),array('a')), size_format( $memory ), 'http://codex.wordpress.org/Editing_wp-config.php#Increasing_memory_allocated_to_PHP' ) . '</mark>';
							} else {
								echo '<mark class="yes">' . size_format( $memory ) . '</mark>';
							}
						?></td>
					</tr>
					
					<tr>
						<td data-export-label="WP Debug Mode"><?php esc_html_e( 'WP Debug Mode', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Displays whether or not WordPress is in Debug Mode.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php if ( defined('WP_DEBUG') && WP_DEBUG ) echo '<mark class="yes">&#10004;</mark>'; else echo '<mark class="no">&ndash;</mark>'; ?></td>
					</tr>
					
					<tr>
						<td data-export-label="Language"><?php esc_html_e( 'Language', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The current language used by WordPress. Default = English', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php echo get_locale() ?></td>
					</tr>
					
				</tbody>
				
			</table>
			
			
			<table class="widefat" cellspacing="0">
			
				<thead>
					<tr>
						<th colspan="3" data-export-label="Server Environment"><?php esc_html_e( 'Server Environment', 'ct-theme' ); ?></th>
					</tr>
				</thead>
				
				<tbody>
				
					<tr>
						<td data-export-label="Server Info"><?php esc_html_e( 'Server Info', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Information about the web server that is currently hosting your site.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php echo esc_html( $_SERVER['SERVER_SOFTWARE'] ); ?></td>
					</tr>
					
					<tr>
						<td data-export-label="PHP Version"><?php esc_html_e( 'PHP Version', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of PHP installed on your hosting server.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php if ( function_exists( 'phpversion' ) ) echo esc_html( phpversion() ); ?></td>
					</tr>
					
					<?php if ( function_exists( 'ini_get' ) ) : ?>
					
						<tr>
							<td data-export-label="PHP Post Max Size"><?php esc_html_e( 'PHP Post Max Size', 'ct-theme' ); ?>:</td>
							<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The largest filesize that can be contained in one post.', 'ct-theme' ) . '">[?]</a>'; ?></td>
							<td><?php echo size_format( $this->let_to_num( ini_get('post_max_size') ) ); ?></td>
						</tr>
						
						<tr>
							<td data-export-label="PHP Time Limit"><?php esc_html_e( 'PHP Time Limit', 'ct-theme' ); ?>:</td>
							<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The amount of time (in seconds) that your site will spend on a single operation before timing out (to avoid server lockups)', 'ct-theme' ) . '">[?]</a>'; ?></td>
							<td><?php
								$time_limit = ini_get('max_execution_time');
	
								if ( $time_limit > 0 && $time_limit < 30 ) {
									echo '<mark class="error">' . sprintf( wp_kses(__( '%s - We recommend setting max execution time to at least 180. See: <a href="%s" target="_blank">Increasing max execution to PHP</a>', 'ct-theme'),array('a')), $time_limit, 'http://codex.wordpress.org/Common_WordPress_Errors#Maximum_execution_time_exceeded' ) . '</mark>';
								} else {
									echo '<mark class="yes">' . $time_limit . '</mark>';
								}
							?></td>
						</tr>
						
						<tr>
							<td data-export-label="PHP Max Input Vars"><?php esc_html_e( 'PHP Max Input Vars', 'ct-theme' ); ?>:</td>
							<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The maximum number of variables your server can use for a single function to avoid overloads.', 'ct-theme' ) . '">[?]</a>'; ?></td>
							<td><?php
								$max_input_vars = ini_get('max_input_vars');
	
								if ( $max_input_vars < 1000 ) {
									echo '<mark class="error">' . sprintf( esc_html__( '%s - Max input vars limitation will truncate POST data such as menus.', 'ct-theme' ), $max_input_vars ) . '</mark>';
								} else {
									echo '<mark class="yes">' . $max_input_vars . '</mark>';
								}
							?></td>
						</tr>
						
						<tr>
							<td data-export-label="SUHOSIN Installed"><?php esc_html_e( 'SUHOSIN Installed', 'ct-theme' ); ?>:</td>
							<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Suhosin is an advanced protection for PHP installations. It was designed to protect your servers on the one hand against a number of well known problems in PHP applications and on the other hand against potential unknown vulnerabilities within these applications or the PHP core itself. If enabled on your server, Suhosin may need to be configured to increase its data submission limits.', 'ct-theme' ) . '">[?]</a>'; ?></td>
							<td><?php echo extension_loaded( 'suhosin' ) ? '&#10004;' : '&ndash;'; ?></td>
						</tr>
						
					<?php endif; ?>
					
					<tr>
						<td data-export-label="MySQL Version"><?php esc_html_e( 'MySQL Version', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The version of MySQL installed on your hosting server.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td>
							<?php
								global $wpdb;
								echo $wpdb->db_version();
							?>
						</td>
					</tr>
					
					<tr>
						<td data-export-label="Max Upload Size"><?php esc_html_e( 'Max Upload Size', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The largest filesize that can be uploaded to your WordPress installation.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php echo size_format( wp_max_upload_size() ); ?></td>
					</tr>
					
					<tr>
						<td data-export-label="Default Timezone is UTC"><?php esc_html_e( 'Default Timezone is UTC', 'ct-theme' ); ?>:</td>
						<td class="help"><?php echo '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'The default timezone for your server.', 'ct-theme' ) . '">[?]</a>'; ?></td>
						<td><?php
							$default_timezone = date_default_timezone_get();
							if ( 'UTC' !== $default_timezone ) {
								echo '<mark class="error">&#10005; ' . sprintf( esc_html__( 'Default timezone is %s - it should be UTC', 'ct-theme' ), $default_timezone ) . '</mark>';
							} else {
								echo '<mark class="yes">&#10004;</mark>';
							} ?>
						</td>
					</tr>
					
					<?php
						$checks = array();
			
						// fsockopen/cURL
						$checks['fsockopen_curl']['name'] = 'fsockopen/cURL';
						$checks['fsockopen_curl']['help'] = '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'Plugins may use it when communicating with remote services.', 'ct-theme' ) . '">[?]</a>';
			
						if ( function_exists( 'fsockopen' ) || function_exists( 'curl_init' ) ) {
							$checks['fsockopen_curl']['success'] = true;
						} else {
							$checks['fsockopen_curl']['success'] = false;
							$checks['fsockopen_curl']['note']    = esc_html__( 'Your server does not have fsockopen or cURL enabled. Contact your hosting provider.', 'ct-theme' ). '</mark>';
						}
			
						// DOMDocument
						$checks['dom_document']['name'] = 'DOMDocument';
						$checks['dom_document']['help'] = '<a href="#" class="help_tip" data-tip="' . esc_attr__( 'WordPress Importer use DOMDocument.', 'ct-theme' ) . '">[?]</a>';
			
						if ( class_exists( 'DOMDocument' ) ) {
							$checks['dom_document']['success'] = true;
						} else {
							$checks['dom_document']['success'] = false;
							$checks['dom_document']['note']    = sprintf( wp_kses(__( 'Your server does not have the <a href="%s">DOMDocument</a> class enabled. Contact your hosting provider.', 'ct-theme'),array('a')), 'http://php.net/manual/en/class.domdocument.php' ) . '</mark>';
						}
			

					?>
					
				</tbody>
				
			</table>
			
			<table class="widefat" cellspacing="0">
			
				<thead>
					<tr>
						<th colspan="3" data-export-label="Theme"><?php esc_html_e( 'Theme', 'ct-theme' ); ?></th>
					</tr>
				</thead>

				<tbody>
				
					<tr>
						<td data-export-label="Name"><?php esc_html_e( 'Name', 'ct-theme' ); ?>:</td>
						<td class="help"></td>
						<td>CT-Theme</td>
					</tr>
					
					<tr>
						<td data-export-label="Version"><?php esc_html_e( 'Version', 'ct-theme' ); ?>:</td>
						<td class="help"></td>
						<td><?php echo CT_THEME_VERSION; ?></td>
					</tr>

				</tbody>
			</table>


		</div>	
		<?php	
	}
	
}

$cturkServerStatus = new cturkServerStatus;
