<?php

require_once get_template_directory() . '/includes/ct-plugins/class-tgm-plugin-activation.php';


/* ---------------------------------------------------------------------------
 *	TGM Plugin Activation
 * --------------------------------------------------------------------------- */
add_action( 'tgmpa_register', 'ct_theme_register_required_plugins' );
if( ! function_exists( 'ct_theme_register_required_plugins' ) )
{
	function ct_theme_register_required_plugins() {
	
		$plugins = array(
				
			// required -----------------------------	
			
			array(	
				'name'               	=> esc_html__('Slider Revolution', 'ct-theme'), // The plugin name.
				'slug'               	=> 'revslider', // The plugin slug (typically the folder name).
				'source'   				=> 'http://cod3turk.com/plugins/revslider.zip', // The plugin source.
				'required'           	=> false, // If false, the plugin is only 'recommended' instead of required.
				'version'            	=> '5.2.6', // E.g. 1.0.0. If set, the active plugin must be this version or higher. If the plugin version is higher than the plugin version installed, the user will be notified to update the plugin.
// 				'force_activation'   	=> false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
// 				'force_deactivation' 	=> false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
// 				'external_url'       	=> '', // If set, overrides default API URL and points to an external URL.
// 				'is_callable'        	=> '', // If set, this callable will be be checked for availability to determine if a plugin is active.
			),
	
			array(
				'name'     				=> esc_html__('Contact Form 7', 'ct-theme'),
				'slug'     				=> 'contact-form-7',	
				'required' 				=> true,
				'external_url'			=> 'http://wordpress.org/plugins/contact-form-7/',
			),
				
			// recommended -----------------------------

			array(
				'name'     				=> esc_html__('Duplicate Post', 'ct-theme'),
				'slug'     				=> 'duplicate-post',
				'required' 				=> false,
				'external_url'			=> 'https://wordpress.org/plugins/duplicate-post/',
			),
				
			array(
				'name'     				=> esc_html__('Force Regenerate Thumbnails', 'ct-theme'),
				'slug'     				=> 'force-regenerate-thumbnails',
				'required' 				=> false,
				'external_url'			=> 'https://wordpress.org/plugins/force-regenerate-thumbnails/',
			),
				
			array(
				'name'     				=> esc_html__('Layer Slider', 'ct-theme'),
				'slug'     				=> 'LayerSlider',
				'source'   				=> 'http://cod3turk.com/plugins/layerslider.zip',
				'required' 				=> false,
				'version' 				=> '5.6.9',
			),
	
	
			array(
				'name'     				=> esc_html__('CT Shortcode', 'ct-theme'),
				'slug'     				=> 'ct-shortcode',
				'source'   				=> 'http://cod3turk.com/plugins/ct-shortcode.zip',
				'required' 				=> false,
				'version' 				=> '1.0',
			),
			
			array(
				'name'     				=> esc_html__('Visual Composer', 'ct-theme'),
				'slug'     				=> 'js_composer',
				'source'   				=> 'http://cod3turk.com/plugins/js_composer.zip',
				'required' 				=> false,
				'version' 				=> '4.12',
			),
			
			array(
				'name'     				=> esc_html__('One Click Demo Import', 'ct-theme'),
				'slug'     				=> 'one-click-demo-import',
				'source'   				=> 'http://cod3turk.com/plugins/one-click-demo-import.zip',
				'required' 				=> false,
				'version' 				=> '1.2.0',
			),
	
		);
	
		$config = array(

			'id'           	=> 'ct-theme',        		// Unique ID for hashing notices for multiple instances of TGMPA.
			'default_path' 	=> '',                      // Default absolute path to bundled plugins.
			'menu'         	=> 'tgmpa-install-plugins', // Menu slug.
			'parent_slug'  	=> 'themes.php',            // Parent menu slug.
			'capability'   	=> 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
			'has_notices'  	=> true,                    // Show admin notices or not.
			'dismissable'  	=> true,                    // If false, a user cannot dismiss the nag message.
			'dismiss_msg'  	=> '',                      // If 'dismissable' is false, this message will be output at top of nag.
			'is_automatic'	=> false,                   // Automatically activate plugins after installation or not.
			'message' 		=> '<div class="ct-theme-tgm-message">'. wp_kses(__( 'If you are not sure about server\'s settings and limits, please activate <u>necessary plugins ONLY</u>', 'ct-theme' ), array('u')) .'</div>',	// Message to output right before the plugins table
			'strings'      	=> array(
				'page_title'                      	=> esc_html__( 'Install Required Plugins', 'ct-theme' ),
				'menu_title'                     	=> esc_html__( 'Install Plugins', 'ct-theme' ),
				'installing'                      	=> esc_html__( 'Installing Plugin: %s', 'ct-theme' ), // %s = plugin name.
				'oops'                            	=> esc_html__( 'Something went wrong with the plugin API.', 'ct-theme' ),
				'notice_can_install_required'     	=> _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'ct-theme' ),
				'notice_can_install_recommended'  	=> _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'ct-theme' ),
				'notice_cannot_install'           	=> _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'ct-theme' ),
				'notice_can_activate_required'    	=> _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'ct-theme' ),
				'notice_can_activate_recommended' 	=> _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'ct-theme' ),
				'notice_cannot_activate'          	=> _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'ct-theme' ),
				'notice_ask_to_update'            	=> _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'ct-theme' ),
				'notice_cannot_update'            	=> _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'ct-theme' ),
				'install_link'                    	=> _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'ct-theme' ),
				'activate_link'                   	=> _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'ct-theme' ),
				'return'                          	=> esc_html__( 'Return to Required Plugins Installer', 'ct-theme' ),
				'plugin_activated'                	=> esc_html__( 'Plugin activated successfully.', 'ct-theme' ),
				'complete'                        	=> esc_html__( 'All plugins installed and activated successfully. %s', 'ct-theme' ), // %s = dashboard link.
				'nag_type'                        	=> 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
			),
				
		);
	
		tgmpa( $plugins, $config );
	}
}

