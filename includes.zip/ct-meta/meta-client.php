<?php
/**
 * Client custom meta fields.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */



/* ---------------------------------------------------------------------------
 * Edit columns
 * --------------------------------------------------------------------------- */
function ct_theme_client_edit_columns($columns)
{
	$newcolumns = array(
		"cb" 					=> "<input type=\"checkbox\" />",
		"client_thumbnail" 		=> esc_html__('Thumbnail','ct-theme'),
		"title" 				=> 'Title',
		"client_types" 			=> esc_html__('Categories','ct-theme'),
		"client_order" 			=> esc_html__('Order','ct-theme'),
	);
	$columns = array_merge($newcolumns, $columns);	
	
	return $columns;
}
add_filter("manage_edit-client_columns", "ct_theme_client_edit_columns");  


/* ---------------------------------------------------------------------------
 * Custom columns
 * --------------------------------------------------------------------------- */
function ct_theme_client_custom_columns($column)
{
	global $post;
	switch ($column)
	{
		case "client_thumbnail":
			if ( has_post_thumbnail() ) { the_post_thumbnail('50x50'); }
			break;	
		case "client_types":
			echo get_the_term_list($post->ID, 'client-types', '', ', ','');
			break;
		case "client_order":
			echo $post->menu_order;
			break;	
	}
}
add_action("manage_posts_custom_column",  "ct_theme_client_custom_columns"); 


/*-----------------------------------------------------------------------------------*/
/*	Define Metabox Fields
/*-----------------------------------------------------------------------------------*/

$ct_theme_client_meta_box = array(
	'id' 		=> 'ct-theme-meta-client',
	'title' 	=> esc_html__('Client Options','ct-theme'),
	'page' 		=> 'client',
	'context' 	=> 'normal',
	'priority' 	=> 'high',
	'fields' 	=> array(
			
		array(
			'id' 		=> 'ct-theme-post-link',
			'type' 		=> 'text',
			'title' 	=> esc_html__('Link', 'ct-theme'),
			'sub_desc'	=> esc_html__('Link to client`s site', 'ct-theme'),
		),

	),
);


/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/ 
function ct_theme_client_meta_add() {
	global $ct_theme_client_meta_box;
	add_meta_box($ct_theme_client_meta_box['id'], $ct_theme_client_meta_box['title'], 'ct_theme_client_show_box', $ct_theme_client_meta_box['page'], $ct_theme_client_meta_box['context'], $ct_theme_client_meta_box['priority']);
}
add_action('admin_menu', 'ct_theme_client_meta_add');


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function ct_theme_client_show_box() {
	global $ct_theme_Options, $ct_theme_client_meta_box, $post;
	$ct_theme_Options->_enqueue();
 	
	// Use nonce for verification
	echo '<div id="ct-theme-wrapper">';
		echo '<input type="hidden" name="ct_theme_client_meta_nonce" value="', wp_create_nonce(CT_THEME_DIR), '" />';
		echo '<table class="form-table">';
			echo '<tbody>';
	 
				foreach ($ct_theme_client_meta_box['fields'] as $field) {
					$meta = get_post_meta($post->ID, $field['id'], true);
					if( ! key_exists('std', $field) ) $field['std'] = false;
					$meta = ( $meta || $meta==='0' ) ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES ));
					ct_theme_meta_field_input( $field, $meta );
				}
	 
			echo '</tbody>';
		echo '</table>';
	echo '</div>';
}


/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/
function ct_theme_client_save_data($post_id) {
	global $ct_theme_client_meta_box;
 
	// verify nonce
	if( key_exists( 'ct_theme_client_meta_nonce',$_POST ) ) {
		if ( ! wp_verify_nonce( $_POST['ct_theme_client_meta_nonce'], CT_THEME_DIR ) ) {
			return $post_id;
		}
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ( (key_exists('post_type', $_POST)) && ('page' == $_POST['post_type']) ) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
 
	foreach ($ct_theme_client_meta_box['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		if( key_exists($field['id'], $_POST) ) {
			$new = $_POST[$field['id']];
		} else {
//			$new = ""; // problem with "quick edit"
			continue;
		}
 
		if ( isset($new) && $new != $old) {
			update_post_meta($post_id, $field['id'], $new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
}
add_action('save_post', 'ct_theme_client_save_data');
