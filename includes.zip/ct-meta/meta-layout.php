<?php
/**
 * Layout custom meta fields.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */


/*-----------------------------------------------------------------------------------*/
/*	Define Metabox Fields
/*-----------------------------------------------------------------------------------*/

$ct_theme_layout_meta_box = array(
	'id' 		=> 'ct-theme-meta-layout',
	'title' 	=> esc_html__('Layout Options','ct-theme'),
	'page' 		=> 'layout',
	'context' 	=> 'normal',
	'priority'	=> 'high',
	'fields' 	=> array(
			
		array(
			'id' 		=> 'ct-theme-post-info-layout',
			'type' 		=> 'info',
			'title' 	=> '',
			'desc' 		=> esc_html__('Layout', 'ct-theme'),
			'class' 	=> 'ct-theme-info',
		),

		array(
			'id'		=> 'ct-theme-post-layout',
			'type' 		=> 'radio_img',
			'title' 	=> esc_html__('Layout', 'ct-theme'),
			'options' 	=> array(
				'full-width' 	=> array('title' => 'Full width', 	'img' => ct_theme_OPTIONS_URI.'img/select/style/full-width.png'),
				'boxed' 		=> array('title' => 'Boxed', 		'img' => ct_theme_OPTIONS_URI.'img/select/style/boxed.png'),
			),
			'std' 		=> 'full-width',
			'class' 	=> 'wide',
		),
	
		array(
			'id' 		=> 'ct-theme-post-info-background',
			'type' 		=> 'info',
			'title' 	=> '',
			'desc' 		=> esc_html__('Background', 'ct-theme'),
			'class' 	=> 'ct-theme-info',
		),
		
		array(
			'id' 		=> 'ct-theme-post-bg',
			'type' 		=> 'upload',
			'title' 	=> esc_html__('Image', 'ct-theme'),
		),
		
		array(
			'id' 		=> 'ct-theme-post-bg-pos',
			'type' 		=> 'select',
			'title' 	=> esc_html__('Position', 'ct-theme'),
			'desc' 		=> esc_html__('This option can be used only with your custom image selected above', 'ct-theme'),
			'options' 	=> cturka_bg_position(),
			'std' 		=> 'center top no-repeat',
		),
			
		array(
			'id' 		=> 'ct-theme-post-info-logo',
			'type' 		=> 'info',
			'title' 	=> '',
			'desc' 		=> esc_html__('Logo', 'ct-theme'),
			'class' 	=> 'ct-theme-info',
		),
	
		array(
			'id'		=> 'ct-theme-post-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Logo', 'ct-theme'),
		),
			
		array(
			'id'		=> 'ct-theme-post-retina-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Retina', 'ct-theme'),
			'desc'		=> esc_html__('Retina Logo should be 2x larger than Custom Logo', 'ct-theme'),
			'sub_desc'	=> esc_html__('optional', 'ct-theme'),
		),
			
		array(
			'id'		=> 'ct-theme-post-sticky-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Sticky Header', 'ct-theme'),
			'sub_desc'	=> esc_html__('optional', 'ct-theme'),
			'desc'		=> esc_html__('Use if you want different logo for Sticky Header', 'ct-theme'),
		),	
		
		array(
			'id'		=> 'ct-theme-post-sticky-retina-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Sticky Header Retina', 'ct-theme'),
			'sub_desc'	=> esc_html__('optional', 'ct-theme'),
			'desc'		=> esc_html__('Retina Logo should be 2x larger than Sticky Logo', 'ct-theme'),
		),
			
		array(
			'id'		=> 'ct-theme-post-responsive-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Mobile', 'ct-theme'),
			'desc'		=> esc_html__('Use if you want different logo for Mobile ( < 768px )', 'ct-theme'),
		),
		
		array(
			'id'		=> 'ct-theme-post-responsive-retina-logo-img',
			'type'		=> 'upload',
			'title'		=> esc_html__('Mobile Retina', 'ct-theme'),
			'desc'		=> esc_html__('Retina Logo should be 2x larger than Mobile Logo', 'ct-theme'),
		),
			
		array(
			'id' 		=> 'ct-theme-post-info-header',
			'type' 		=> 'info',
			'title' 	=> '',
			'desc' 		=> esc_html__('Header', 'ct-theme'),
			'class' 	=> 'ct-theme-info',
		),
			
		array(
			'id' 		=> 'ct-theme-post-header-style',
			'type' 		=> 'radio_img',
			'title' 	=> esc_html__('Style', 'ct-theme'),
			'options'	=> cturka_header_style(),
			'std'		=> 'classic',
			'class'		=> 'wide',
		),
				
		array(
			'id'		=> 'ct-theme-post-minimalist-header',
			'type'		=> 'select',
			'title'		=> esc_html__('Minimalist', 'ct-theme'),
			'desc'		=> esc_html__('Header without background image & padding', 'ct-theme'),
			'options'	=> array(
				'0' 		=> 'Default | OFF',
				'1' 		=> 'Minimalist | ON',
				'no' 		=> 'Minimalist without Header space',
			),
			'std'			=> '1',
		),
			
		array(
			'id'		=> 'ct-theme-post-sticky-header',
			'type'		=> 'switch',
			'title'		=> esc_html__('Sticky', 'ct-theme'),
			'options'	=> array('1' => 'On','0' => 'Off'),
			'std'		=> '1'
		),

		array(
			'id'		=> 'ct-theme-post-sticky-header-style',
			'type'		=> 'select',
			'title'		=> esc_html__('Sticky | Style', 'ct-theme'),
			'options'	=> array(
				'white'		=> 'White',
				'dark'		=> 'Dark',
			),
		),
			
		array(
			'id' 		=> 'ct-theme-post-info-colors',
			'type' 		=> 'info',
			'title' 	=> '',
			'desc' 		=> esc_html__('Colors', 'ct-theme'),
			'class' 	=> 'ct-theme-info',
		),
	
		array(
			'id' 		=> 'ct-theme-post-skin',
			'type' 		=> 'select',
			'title' 	=> esc_html__('Skin', 'ct-theme'),
			'sub_desc' 	=> esc_html__('Choose one of the predefined styles or set your own colors', 'ct-theme'),
			'desc' 		=> esc_html__('<strong>Important:</strong> Color options can be used only with the <strong>Custom Skin</strong>', 'ct-theme'),
			'options' 	=> cturka_skin(),
			'std' 		=> 'orange',
		),
			
		array(
			'id' 		=> 'ct-theme-post-background-subheader',
			'type' 		=> 'color',
			'title' 	=> esc_html__('Subheader | Background', 'ct-theme'),
			'std' 		=> '#F7F7F7',
		),
		
		array(
			'id' 		=> 'ct-theme-post-color-subheader',
			'type' 		=> 'color',
			'title' 	=> esc_html__('Subheader | Text color', 'ct-theme'),
			'std' 		=> '#888888',
		),

	),
);


/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/ 
function ct_theme_layout_meta_add() {
	global $ct_theme_layout_meta_box;
	add_meta_box($ct_theme_layout_meta_box['id'], $ct_theme_layout_meta_box['title'], 'ct_theme_layout_show_box', $ct_theme_layout_meta_box['page'], $ct_theme_layout_meta_box['context'], $ct_theme_layout_meta_box['priority']);
}
add_action('admin_menu', 'ct_theme_layout_meta_add');


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function ct_theme_layout_show_box() {
	global $ct_theme_Options, $ct_theme_layout_meta_box, $post;
	$ct_theme_Options->_enqueue();
 	
	// Use nonce for verification
	echo '<div id="ct-theme-wrapper">';
		echo '<input type="hidden" name="ct_theme_layout_meta_nonce" value="', wp_create_nonce(CT_THEME_DIR), '" />';
		
		echo '<table class="form-table">';
			echo '<tbody>';
	 
				foreach ($ct_theme_layout_meta_box['fields'] as $field) {
					$meta = get_post_meta($post->ID, $field['id'], true);
					if( ! key_exists('std', $field) ) $field['std'] = false;
					$meta = ( $meta || $meta==='0' ) ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES ));
					ct_theme_meta_field_input( $field, $meta );
				}
	 
			echo '</tbody>';
		echo '</table>';
	echo '</div>';
}


/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/
function ct_theme_layout_save_data($post_id) {
	global $ct_theme_layout_meta_box;
 
	// verify nonce
	if( key_exists( 'ct_theme_layout_meta_nonce',$_POST ) ) {
		if ( ! wp_verify_nonce( $_POST['ct_theme_layout_meta_nonce'], CT_THEME_DIR ) ) {
			return $post_id;
		}
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ( (key_exists('post_type', $_POST)) && ('page' == $_POST['post_type']) ) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
 
	foreach ($ct_theme_layout_meta_box['fields'] as $field) {
		$old = get_post_meta($post_id, $field['id'], true);
		if( key_exists($field['id'], $_POST) ) {
			$new = $_POST[$field['id']];
		} else {
//			$new = ""; // problem with "quick edit"
			continue;
		}
 
		if ( isset($new) && $new != $old) {
			update_post_meta($post_id, $field['id'], $new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
}
add_action('save_post', 'ct_theme_layout_save_data');
