<?php
/**
 * Builder Template custom meta fields.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */


/*-----------------------------------------------------------------------------------*/
/*	Define Metabox Fields
/*-----------------------------------------------------------------------------------*/
$ct_theme_template_meta_box = array(
		
	'id' 		=> 'ct-theme-meta-template',
	'title' 	=> esc_html__('Template Options','ct-theme'),
	'page' 		=> 'template',
	'context' 	=> 'normal',
	'priority'	=> 'high',
	'fields' 	=> array(),
);


/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/ 
function ct_theme_template_meta_add() {
	global $ct_theme_template_meta_box;
	add_meta_box($ct_theme_template_meta_box['id'], $ct_theme_template_meta_box['title'], 'ct_theme_template_show_box', $ct_theme_template_meta_box['page'], $ct_theme_template_meta_box['context'], $ct_theme_template_meta_box['priority']);
}
add_action('admin_menu', 'ct_theme_template_meta_add');


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function ct_theme_template_show_box() {
	global $ct_theme_Options, $ct_theme_template_meta_box, $post;
	$ct_theme_Options->_enqueue();
 	
	// Use nonce for verification
	echo '<div id="ct-theme-wrapper">';
		echo '<input type="hidden" name="ct_theme_template_meta_nonce" value="', wp_create_nonce(CT_THEME_DIR), '" />';
		
		ct_theme_builder_show();
		
	echo '</div>';
}


/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/
function ct_theme_template_save_data($post_id) {
	global $ct_theme_template_meta_box;
 
	// verify nonce
	if( key_exists( 'ct_theme_template_meta_nonce',$_POST ) ) {
		if ( ! wp_verify_nonce( $_POST['ct_theme_template_meta_nonce'], CT_THEME_DIR ) ) {
			return $post_id;
		}
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ( (key_exists('post_type', $_POST)) && ('page' == $_POST['post_type']) ) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
 
	ct_theme_builder_save($post_id);
}
add_action('save_post', 'ct_theme_template_save_data');
