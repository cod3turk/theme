<?php
/**
 * Page custom meta fields.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */

 
/*-----------------------------------------------------------------------------------*
 * Define Metabox Fields & Add metabox to edit page		 
 * 
 * version 1.1 | Custom Menu 
 * version 1.2 | Layouts
 *-----------------------------------------------------------------------------------*/
function ct_theme_page_meta_add(){
	global $ct_theme_page_meta_box;

	// Custom menu ------------------------------
	$aMenus = array( 0 => '-- Default --' );
	$oMenus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
	

	if( is_array($oMenus) ){

		foreach( $oMenus as $menu ){
			$aMenus[$menu->term_id] = $menu->name;

			$term_trans_id = apply_filters( 'wpml_object_id', $menu->term_id, 'nav_menu', false );
			if( $term_trans_id != $menu->term_id ){
				unset( $aMenus[$menu->term_id] );
			}
		}
	}
	
	// Layouts ----------------------------------
	$layouts = array( 0 => '-- Theme Options --' );
	$args = array(
		'post_type' => 'layout',
		'posts_per_page'=> -1,
	);
	$lay = get_posts( $args );
	
	if( is_array( $lay ) ){
		foreach ( $lay as $v ){
			$layouts[$v->ID] = $v->post_title;
		}
	}
	
	$ct_theme_page_meta_box = array(
		'id' 		=> 'ct-theme-meta-page',
		'title' 	=> esc_html__('Page Options','ct-theme'),
		'page' 		=> 'page',
		'context' 	=> 'normal',
		'priority' 	=> 'default',
		'fields'	=> array(
	
			// layout -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-layout',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Layout', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
				
			array(
				'id'		=> 'ct-theme-post-hide-content',
				'type'		=> 'switch',
				'title'		=> esc_html__('Hide The Content', 'ct-theme'), 
				'sub_desc'	=> esc_html__('Hide the content from the WordPress editor', 'ct-theme'),
				'desc'		=> wp_kses(__('<strong>Turn it ON if you build content using Content Builder</strong><br />Use the Content item if you want to display the Content from editor within the Content Builder', 'ct-theme'),array('strong','br')),
				'options'	=> array('1' => 'On', '0' => 'Off'),
				'std'		=> '0'
			),

			array(
				'id' 		=> 'ct-theme-post-layout',
				'type' 		=> 'radio_img',
				'title' 	=> esc_html__('Layout', 'ct-theme'),
				'desc' 		=> wp_kses(__('<b>Full width</b> sections works only <b>without</b> sidebars', 'ct-theme'),array('b')),
				'options' 	=> array(
					'no-sidebar' 	=> array('title' => 'Full width No sidebar', 'img' => ct_theme_OPTIONS_URI.'img/1col.png'),
					'left-sidebar'	=> array('title' => 'Left Sidebar', 'img' => ct_theme_OPTIONS_URI.'img/2cl.png'),
					'right-sidebar' => array('title' => 'Right Sidebar', 'img' => ct_theme_OPTIONS_URI.'img/2cr.png'),
					'both-sidebars' => array('title' => 'Both Sidebars', 'img' => ct_theme_OPTIONS_URI.'img/2sb.png'),
				),
				'std' 		=> ct_theme_opts_get( 'sidebar-layout' ),
			),
				
			array(
				'id' 		=> 'ct-theme-post-sidebar',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Sidebar', 'ct-theme'),
				'desc' 		=> esc_html__('Shows only if layout with sidebar is selected', 'ct-theme'),
				'options' 	=> ct_theme_opts_get( 'sidebars' ),
			),
			
			array(
				'id' 		=> 'ct-theme-post-sidebar2',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Sidebar 2nd', 'ct-theme'),
				'desc' 		=> esc_html__('Shows only if layout with both sidebars is selected', 'ct-theme'),
				'options' 	=> ct_theme_opts_get( 'sidebars' ),
			),		
				
			// media -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-media',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Media', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
	
			array(
				'id' 		=> 'ct-theme-post-slider',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Slider | Revolution Slider', 'ct-theme'),
				'desc' 		=> wp_kses(__('Select one from the list of available <a target="_blank" href="admin.php?page=revslider">Revolution Sliders</a>', 'ct-theme'),array('a')),
				'options' 	=> ct_theme_get_sliders(),
			),
			
			array(
				'id' 		=> 'ct-theme-post-slider-layer',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Slider | Layer Slider', 'ct-theme'), 
				'desc' 		=> wp_kses(__('Select one from the list of available <a target="_blank" href="admin.php?page=layerslider">Layer Sliders</a>', 'ct-theme'),array('a')),
				'options' 	=> ct_theme_get_sliders_layer(),
			),
				
			array(
				'id' 		=> 'ct-theme-post-slider-shortcode',
				'type' 		=> 'text',
				'title' 	=> esc_html__('Slider | Shortcode', 'ct-theme'), 
				'desc' 		=> esc_html__('Paste your slider shortcode here if you use slider other than Revolution or Layer', 'ct-theme'),
			),
				
			array(
				'id'		=> 'ct-theme-post-subheader-image',
				'type'		=> 'upload',
				'title'		=> esc_html__('Subheader | Image', 'ct-theme'),
			),

			// options -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-options',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Options', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
				
			array(
				'id'		=> 'ct-theme-post-one-page',
				'type'		=> 'switch',
				'title'		=> esc_html__('One Page', 'ct-theme'),
				'options'	=> array( '0' => 'Off', '1' => 'On' ),
				'std'		=> '0'
			),

			array(
				'id'		=> 'ct-theme-post-hide-title',
				'type'		=> 'switch',
				'title'		=> esc_html__('Subheader | Hide', 'ct-theme'),
				'options'	=> array('1' => 'On', '0' => 'Off'),
				'std'		=> '0'
			),
				
			array(
				'id' 		=> 'ct-theme-post-remove-padding',
				'type' 		=> 'switch',
				'title' 	=> esc_html__('Content | Remove Padding', 'ct-theme'),
				'desc' 		=> esc_html__('Remove default Content Padding', 'ct-theme'),
				'options' 	=> array('1' => 'On','0' => 'Off'),
				'std' 		=> '0'
			),
			
			array(
				'id' 		=> 'ct-theme-post-custom-layout',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Custom | Layout', 'ct-theme'),
				'desc' 		=> esc_html__('Custom Layout overwrites Theme Options', 'ct-theme'),
				'options' 	=> $layouts,
			),
			
			array(
				'id' 		=> 'ct-theme-post-menu',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Custom | Menu', 'ct-theme'),
				'options' 	=> $aMenus,
			),
	
			// seo -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-seo',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('SEO', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
	
			array(
				'id' 		=> 'ct-theme-meta-seo-title',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Title', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-meta-seo-description',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Description', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-meta-seo-keywords',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Keywords', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
				
			// custom -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-custom',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Custom CSS', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
			
			array(
				'id' 		=> 'ct-theme-post-css',
				'type' 		=> 'textarea',
				'title' 	=> esc_html__('Custom | CSS', 'ct-theme'),
				'desc' 		=> esc_html__('Paste your custom CSS code for this page', 'ct-theme'),
				'class' 	=> 'full-width',
			),
			
		),
	);
	
	add_meta_box($ct_theme_page_meta_box['id'], $ct_theme_page_meta_box['title'], 'ct_theme_page_show_box', $ct_theme_page_meta_box['page'], $ct_theme_page_meta_box['context'], $ct_theme_page_meta_box['priority']);
}
add_action('admin_menu', 'ct_theme_page_meta_add');


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function ct_theme_page_show_box() {
	global $ct_theme_Options, $ct_theme_page_meta_box, $post;
	$ct_theme_Options->_enqueue();
 	
	// Use nonce for verification
	echo '<div id="ct-theme-wrapper">';
		echo '<input type="hidden" name="ct_theme_page_meta_nonce" value="', wp_create_nonce(CT_THEME_DIR), '" />';
		
		ct_theme_builder_show();

		echo '<table class="form-table">';
			echo '<tbody>';		
	 
				foreach ($ct_theme_page_meta_box['fields'] as $field) {
					$meta = get_post_meta($post->ID, $field['id'], true);
					if( ! key_exists('std', $field) ) $field['std'] = false;
					$meta = ( $meta || $meta==='0' ) ? $meta : stripslashes(htmlspecialchars(($field['std']), ENT_QUOTES ));
					ct_theme_meta_field_input( $field, $meta );
				}
	 
			echo '</tbody>';
		echo '</table>';
		
	echo '</div>';
}


/*-----------------------------------------------------------------------------------*/
/*	Save data when page is edited
/*-----------------------------------------------------------------------------------*/
function ct_theme_page_save_data($post_id) {
	global $ct_theme_page_meta_box;
 
	// verify nonce
	if( key_exists( 'ct_theme_page_meta_nonce',$_POST ) ) {
		if ( ! wp_verify_nonce( $_POST['ct_theme_page_meta_nonce'], CT_THEME_DIR ) ) {
			return $post_id;
		}
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ( (key_exists('post_type', $_POST)) && ('page' == $_POST['post_type']) ) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
	
	ct_theme_builder_save($post_id);

	// check and save fields ( $ct_theme_page_meta_box['fields'] )
	foreach ( (array)$ct_theme_page_meta_box['fields'] as $field ) {
		$old = get_post_meta($post_id, $field['id'], true);
		if( key_exists($field['id'], $_POST) ) {
			$new = $_POST[$field['id']];
		} else {
//			$new = ""; // problem with "quick edit"
			continue;
		}
 
		if ( isset($new) && $new != $old) {
			update_post_meta($post_id, $field['id'], $new);
		} elseif ('' == $new && $old) {
			delete_post_meta($post_id, $field['id'], $old);
		}
	}
}
add_action('save_post', 'ct_theme_page_save_data');
