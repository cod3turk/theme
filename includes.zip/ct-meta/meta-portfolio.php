<?php
/**
 * Portfolio custom meta fields.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */


/* ---------------------------------------------------------------------------
 * Edit columns
 * --------------------------------------------------------------------------- */
function ct_theme_portfolio_edit_columns($columns)
{
	$newcolumns = array(
		"cb" 					=> "<input type=\"checkbox\" />",
		"portfolio_thumbnail" 	=> esc_html__('Thumbnail','ct-theme'),
		"title" 				=> 'Title',
		"portfolio_types" 		=> esc_html__('Categories','ct-theme'),
		"portfolio_order" 		=> esc_html__('Order','ct-theme'),
	);
	$columns = array_merge($newcolumns, $columns);	
	
	return $columns;
}
add_filter("manage_edit-portfolio_columns", "ct_theme_portfolio_edit_columns");  


/* ---------------------------------------------------------------------------
 * Custom columns
 * --------------------------------------------------------------------------- */
function ct_theme_portfolio_custom_columns($column)
{
	global $post;
	switch ($column)
	{
		case "portfolio_thumbnail":
			if ( has_post_thumbnail() ) { the_post_thumbnail('50x50'); }
			break;
		case "portfolio_types":
			echo get_the_term_list($post->ID, 'portfolio-types', '', ', ','');
			break;
		case "portfolio_order":
			echo $post->menu_order;
			break;		
	}
}
add_action("manage_posts_custom_column",  "ct_theme_portfolio_custom_columns"); 



/*-----------------------------------------------------------------------------------*/
/*	Add metabox to edit page
/*-----------------------------------------------------------------------------------*/ 
function ct_theme_portfolio_meta_add() {
	global $ct_theme_portfolio_meta_box;
	
	// Layouts ----------------------------------
	$layouts = array( 0 => '-- Theme Options --' );
	$args = array(
		'post_type' => 'layout',
		'posts_per_page'=> -1,
	);
	$lay = get_posts( $args );
	
	if( is_array( $lay ) ){
		foreach ( $lay as $v ){
			$layouts[$v->ID] = $v->post_title;
		}
	}
	
	$ct_theme_portfolio_meta_box = array(
		'id' 		=> 'ct-theme-meta-portfolio',
		'title' 	=> esc_html__('Portfolio Item Options','ct-theme'),
		'page' 		=> 'portfolio',
		'context' 	=> 'normal',
		'priority' 	=> 'high',
		'fields' 	=> array(
				
			// layout -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-layout',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Layout', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
	
			array(
				'id' 		=> 'ct-theme-post-hide-content',
				'type' 		=> 'switch',
				'title' 	=> esc_html__('Hide the content', 'ct-theme'),
				'sub_desc' 	=> esc_html__('Hide the content from the WordPress editor', 'ct-theme'),
				'desc' 		=> wp_kses(__('<strong>Turn it ON if you build content using Content Builder</strong><br />Use the Content item if you want to display the Content from editor within the Content Builder', 'ct-theme'),array('strong','br')),
				'options' 	=> array('1' => 'On', '0' => 'Off'),
				'std' 		=> '0'
			),
			
			array(
				'id' 		=> 'ct-theme-post-layout',
				'type' 		=> 'radio_img',
				'title' 	=> esc_html__('Layout', 'ct-theme'),
				'desc' 		=> wp_kses(__('<b>Full width</b> sections works only <b>without</b> sidebars', 'ct-theme'),array('b')),
				'options' 	=> array(
					'no-sidebar' 	=> array('title' => 'Full width. No sidebar', 'img' => ct_theme_OPTIONS_URI.'img/1col.png'),
					'left-sidebar' 	=> array('title' => 'Left Sidebar', 'img' => ct_theme_OPTIONS_URI.'img/2cl.png'),
					'right-sidebar'	=> array('title' => 'Right Sidebar', 'img' => ct_theme_OPTIONS_URI.'img/2cr.png'),
					'both-sidebars' => array('title' => 'Both Sidebars', 'img' => ct_theme_OPTIONS_URI.'img/2sb.png'),
				),
				'std' 		=> ct_theme_opts_get( 'sidebar-layout' ),
			),
				
			array(
				'id' 		=> 'ct-theme-post-sidebar',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Sidebar', 'ct-theme'),
				'desc' 		=> esc_html__('Shows only if layout with sidebar is selected', 'ct-theme'),
				'options' 	=> ct_theme_opts_get( 'sidebars' ),
			),
				
			array(
				'id' 		=> 'ct-theme-post-sidebar2',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Sidebar 2nd', 'ct-theme'),
				'desc' 		=> esc_html__('Shows only if layout with both sidebars is selected', 'ct-theme'),
				'options' 	=> ct_theme_opts_get( 'sidebars' ),
			),
				
			array(
				'id' 		=> 'ct-theme-post-template',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Template', 'ct-theme'),
				'options' 	=> array(
					'' 			=> esc_html__( 'Default Template', 'ct-theme' ),
					'builder' 	=> esc_html__( 'Builder', 'ct-theme' ),
					'intro' 	=> esc_html__( 'Intro Header', 'ct-theme' ),
				),
			),
				
			// media -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-media',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Media', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),

			array(
				'id' 		=> 'ct-theme-post-slider',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Slider | Revolution Slider', 'ct-theme'), 
				'desc' 		=> wp_kses(__('Select one from the list of available <a target="_blank" href="admin.php?page=revslider">Revolution Sliders</a>', 'ct-theme'),array('a')),
				'options' 	=> ct_theme_get_sliders(),
			),
			
			array(
				'id' 		=> 'ct-theme-post-slider-layer',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Slider | Layer Slider', 'ct-theme'), 
				'desc' 		=> wp_kses(__('Select one from the list of available <a target="_blank" href="admin.php?page=layerslider">Layer Sliders</a>', 'ct-theme'),array('a')),
				'options' 	=> ct_theme_get_sliders_layer(),
			),

			array(
				'id' 		=> 'ct-theme-post-video',
				'type' 		=> 'text',
				'title' 	=> esc_html__('Video | ID', 'ct-theme'),
				'sub_desc' 	=> esc_html__('YouTube or Vimeo', 'ct-theme'),
				'desc' 		=> wp_kses(__('It`s placed in every YouTube & Vimeo video, for example:<br /><b>YouTube:</b> http://www.youtube.com/watch?v=<u>WoJhnRczeNg</u><br /><b>Vimeo:</b> http://vimeo.com/<u>62954028</u>', 'ct-theme'),array('b','br','u')),
				'class' 	=> 'small-text ct-theme-post-format video'
			),
			
			array(
				'id'		=> 'ct-theme-post-video-mp4',
				'type'		=> 'upload',
				'title'		=> esc_html__('Video | HTML5', 'ct-theme'),
				'sub_desc'	=> esc_html__('m4v [.mp4]', 'ct-theme'),
				'desc'		=> wp_kses(__('<strong>Notice:</strong> HTML5 video works only in moden browsers', 'ct-theme'),array('strong')),
				'class'		=> esc_html__('video', 'ct-theme'),
			),
				
			array(
				'id' 		=> 'ct-theme-post-header-bg',
				'type' 		=> 'upload',
				'title' 	=> esc_html__('Header Image', 'ct-theme'),
			),	

			// description -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-desc',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Description', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
			
			array(
				'id' 		=> 'ct-theme-post-client',
				'type' 		=> 'text',
				'title' 	=> esc_html__('Client', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-post-link',
				'type' 		=> 'text',
				'title' 	=> esc_html__('Website', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-post-task',
				'type' 		=> 'text',
				'title' 	=> esc_html__('Task', 'ct-theme'),
			),
				
			// options -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-options',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Options', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
				
			array(
				'id'		=> 'ct-theme-post-hide-title',
				'type'		=> 'switch',
				'title'		=> esc_html__('Subheader | Hide', 'ct-theme'),
				'options'	=> array('1' => 'On', '0' => 'Off'),
				'std'		=> '0'
			),
				
			array(
				'id' 		=> 'ct-theme-post-remove-padding',
				'type' 		=> 'switch',
				'title' 	=> esc_html__('Content | Remove Padding', 'ct-theme'),
				'desc' 		=> esc_html__('Remove default Content Padding', 'ct-theme'),
				'options' 	=> array('1' => 'On','0' => 'Off'),
				'std' 		=> '0'
			),
				
			array(
				'id' 		=> 'ct-theme-post-slider-header',
				'type' 		=> 'switch',
				'title' 	=> esc_html__('Slider | Show in Header', 'ct-theme'),
				'sub_desc' 	=> esc_html__('Show slider in Header instead of the Content', 'ct-theme'),
				'options' 	=> array( '1' => 'On', '0' => 'Off' ),
				'std' 		=> '0'
			),
			
			array(
				'id' 		=> 'ct-theme-post-custom-layout',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Custom | Layout', 'ct-theme'),
				'desc' 		=> esc_html__('Custom Layout overwrites Theme Options', 'ct-theme'),
				'options' 	=> $layouts,
			),
				

			// advanced -----
			
			array(
				'id' 		=> 'ct-theme-meta-info-advanced',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('Advanced', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
				
			array(
				'id' 		=> 'ct-theme-post-bg',
				'type' 		=> 'upload',
				'title' 	=> esc_html__('Background | Image', 'ct-theme'),
				'desc' 		=> wp_kses(__('for <b>Portfolio Layout: List</b>', 'ct-theme'),array('b')),
			),
				
			array(
				'id' 		=> 'ct-theme-post-bg-hover',
				'type' 		=> 'color',
				'title' 	=> esc_html__('Background | Color', 'ct-theme'),
				'desc' 		=> wp_kses(__('for <b>Portfolio Layout: List & Masonry Hover Details</b>', 'ct-theme'),array('b')),
			),
				
			array(
				'id'		=> 'ct-theme-post-intro',
				'type' 		=> 'checkbox',
				'title' 	=> esc_html__('Intro | Options', 'ct-theme'),
				'desc' 		=> wp_kses(__('for <b>Template: Intro</b>', 'ct-theme'),array('b')),
				'options' 	=> array(
					'light'			=> esc_html__( 'Light | light image, dark text', 'ct-theme' ),
					'full-screen'	=> esc_html__( 'Full Screen', 'ct-theme' ),
					'parallax'		=> esc_html__( 'Parallax', 'ct-theme' ),
				),
			),
				
			array(
				'id' 		=> 'ct-theme-post-size',
				'type' 		=> 'select',
				'title' 	=> esc_html__('Masonry Flat | Item Size', 'ct-theme'),
				'desc' 		=> esc_html__('for <b>Portfolio Layout: Masonry Flat</b>', 'ct-theme'),
				'options' 	=> array(
					''			=> esc_html__('Default','ct-theme'),
					'wide'		=> esc_html__('Wide','ct-theme'),
					'tall'		=> esc_html__('Tall','ct-theme'),
					'wide tall'	=> esc_html__('Big','ct-theme'),
				),
			),
	
			// seo -----
				
			array(
				'id' 		=> 'ct-theme-meta-info-seo',
				'type' 		=> 'info',
				'title' 	=> '',
				'desc' 		=> esc_html__('SEO', 'ct-theme'),
				'class' 	=> 'ct-theme-info',
			),
				
			array(
				'id' 		=> 'ct-theme-meta-seo-title',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Title', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-meta-seo-description',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Description', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
			
			array(
				'id' 		=> 'ct-theme-meta-seo-keywords',
				'type' 		=> 'text',
				'title' 	=> esc_html__('SEO | Keywords', 'ct-theme'),
				'desc' 		=> esc_html__('These settings overriddes theme options settings', 'ct-theme'),
			),
	
		),
	);

	add_meta_box($ct_theme_portfolio_meta_box['id'], $ct_theme_portfolio_meta_box['title'], 'ct_theme_portfolio_show_box', $ct_theme_portfolio_meta_box['page'], $ct_theme_portfolio_meta_box['context'], $ct_theme_portfolio_meta_box['priority']);
}
add_action('admin_menu', 'ct_theme_portfolio_meta_add');


/*-----------------------------------------------------------------------------------*/
/*	Callback function to show fields in meta box
/*-----------------------------------------------------------------------------------*/
function ct_theme_portfolio_show_box() {
	global $ct_theme_Options, $ct_theme_portfolio_meta_box, $post;
	$ct_theme_Options->_enqueue();
 	
	// Use nonce for verification
	echo '<div id="ct-theme-wrapper">';
		echo '<input type="hidden" name="ct_theme_portfolio_meta_nonce" value="', wp_create_nonce(CT_THEME_DIR), '" />';
		
		ct_theme_builder_show();
		
		echo '<table class="form-table">';
			echo '<tbody>';
	 
				foreach ($ct_theme_portfolio_meta_box['fields'] as $field) {
					$meta = get_post_meta($post->ID, $field['id'], true);
					if( ! key_exists('std', $field) ) $field['std'] = false;
					$meta = ( $meta || $meta==='0' ) ? $meta : stripslashes(htmlspecialchars(( $field['std']), ENT_QUOTES ));
					ct_theme_meta_field_input( $field, $meta );
				}
	 
			echo '</tbody>';
		echo '</table>';
	echo '</div>';
}


/*-----------------------------------------------------------------------------------*/
/*	Save data when post is edited
/*-----------------------------------------------------------------------------------*/
function ct_theme_portfolio_save_data($post_id) {
	global $ct_theme_portfolio_meta_box;
 
	// verify nonce
	if( key_exists( 'ct_theme_portfolio_meta_nonce',$_POST ) ) {
		if ( ! wp_verify_nonce( $_POST['ct_theme_portfolio_meta_nonce'], CT_THEME_DIR ) ) {
			return $post_id;
		}
	}
 
	// check autosave
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
		return $post_id;
	}
 
	// check permissions
	if ( (key_exists('post_type', $_POST)) && ('page' == $_POST['post_type']) ) {
		if (!current_user_can('edit_page', $post_id)) {
			return $post_id;
		}
	} elseif (!current_user_can('edit_post', $post_id)) {
		return $post_id;
	}
	
	ct_theme_builder_save($post_id);
 
	if( $ct_theme_portfolio_meta_box && key_exists( 'fields', $ct_theme_portfolio_meta_box ) ){
		foreach ($ct_theme_portfolio_meta_box['fields'] as $field) {
			$old = get_post_meta($post_id, $field['id'], true);
			if( key_exists($field['id'], $_POST) ) {
				$new = $_POST[$field['id']];
			} else {
				continue;
			}
	 
			if ( isset($new) && $new != $old) {
				update_post_meta($post_id, $field['id'], $new);
			} elseif ('' == $new && $old) {
				delete_post_meta($post_id, $field['id'], $old);
			}
		}
	}
}
add_action('save_post', 'ct_theme_portfolio_save_data');
