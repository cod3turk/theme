<?php
/**
 * Widget CT-Theme Login
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */

class ct_theme_Login_Widget extends WP_Widget {

	
	/* ---------------------------------------------------------------------------
	 * Constructor
	 * --------------------------------------------------------------------------- */
	function __construct(){
		
		$widget_ops = array( 'classname' => 'widget_ct_theme_login', 'description' => esc_html__( 'Displays Login Form.', 'ct-theme' ) );
		
		parent::__construct( 'widget_ct_theme_login', esc_html__( 'CT-Theme Login', 'ct-theme' ), $widget_ops );
		
		$this->alt_option_name = 'widget_ct_theme_login';
	}
	
	
	/* ---------------------------------------------------------------------------
	 * Outputs the HTML for this widget.
	 * --------------------------------------------------------------------------- */
	function widget( $args, $instance ) {
		global $user_login;

		if ( ! isset( $args['widget_id'] ) ) $args['widget_id'] = null;
		extract( $args, EXTR_SKIP );
		extract( $instance );

		echo $before_widget;
		
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base);
		
		if( is_user_logged_in() ){
			$user = get_user_by('login', $user_login);
			$title = esc_html__('Welcome','ct-theme').' '.$user->data->display_name;
		}
		
		echo '<div class="ct-theme-login">';
		
			if( $title ) echo $before_title . $title . $after_title;
			
			// validation
			if( isset( $_GET['login'] ) && $_GET['login'] == 'failed'){
				$errcode = $_GET['errcode'];
					
				if( $errcode == "empty_username" || $errcode == "empty_password" ){
					$error = esc_html__('Please enter Username and Password', 'ct-theme');
				}
				elseif( $errcode == 'invalid_username' ){
					$error = esc_html__('Invalid Username', 'ct-theme');
				}
				elseif( $errcode == 'incorrect_password' ){
					$error = esc_html__('Incorrect Password', 'ct-theme');
				}
		
				echo '<div class="alert alert_error">'. $error .'</div>';
			}
		
			if( is_user_logged_in() ){
	
				echo '<div class="avatar-wrapper">'. get_avatar( $user->ID, 64 ) .'</div>';
				
				echo '<div class="author">';
				
					_e('Logged in as ','ct-theme');
					echo '<strong>' . ucfirst( implode(', ', $user->roles)) . '</strong><br />';
					echo '<a href="' . admin_url() . '">'. esc_html__('Dashboard','ct-theme') .'</a>';
					echo '<span class="sep">|</span>';
					echo '<a href="' . admin_url() . 'profile.php">'. esc_html__('Profile','ct-theme') .'</a>';
					echo '<span class="sep">|</span>';
					echo '<a href="' . wp_logout_url(site_url()) . '">'. esc_html__('Logout','ct-theme') .'</a>';
					
				echo '</div>';
	
			} else {

				wp_login_form(array( 'value_remember' => 0,
					'redirect' 			=> site_url(),
// 					'label_username' 	=> esc_html__( 'Username', 'ct-theme' ),
// 					'label_password' 	=> esc_html__( 'Password', 'ct-theme' ),
// 					'label_remember' 	=> esc_html__( 'Remember Me', 'ct-theme' ),
// 					'label_log_in'   	=> esc_html__( 'Log In', 'ct-theme' ),
					'remember' 			=> false
				));
				
				echo '<div class="links">';
					if( $show_register ) echo '<a href="' . wp_registration_url() . '">'. esc_html__('Register','ct-theme') .'</a>';
					if( $show_register && $show_forgotten_password ) echo '<span class="sep">|</span>';
					if( $show_forgotten_password ) echo '<a href="' . wp_registration_url() . '">'. esc_html__('Lost your password?','ct-theme') .'</a>';
				echo '</div>';

			}
		
		echo '</div>'."\n";
		
		echo $after_widget;
	}


	/* ---------------------------------------------------------------------------
	 * Deals with the settings when they are saved by the admin.
	 * --------------------------------------------------------------------------- */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		$instance['title']						= strip_tags( $new_instance['title'] );
// 		$instance['show_remember_me']			= (int) $new_instance['show_remember_me'];
		$instance['show_register']				= (int) $new_instance['show_register'];
		$instance['show_forgotten_password']	= (int) $new_instance['show_forgotten_password'];
		
		return $instance;
	}

	
	/* ---------------------------------------------------------------------------
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 * --------------------------------------------------------------------------- */
	function form( $instance ) {
		
		$title 						= isset( $instance['title']) ? esc_attr( $instance['title'] ) : '';
// 		$show_remember_me 			= isset( $instance['show_remember_me'] ) ? absint( $instance['show_remember_me'] ) : 0;
		$show_register 				= isset( $instance['show_register'] ) ? absint( $instance['show_register'] ) : 0;
		$show_forgotten_password 	= isset( $instance['show_forgotten_password'] ) ? absint( $instance['show_forgotten_password'] ) : 0;
?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'ct-theme' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>

			<p>
				
				<input id="<?php echo esc_attr( $this->get_field_id( 'show_register' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_register' ) ); ?>" type="checkbox" value="1" <?php if( esc_attr( $show_register ) ) echo "checked='checked'" ?> />
				<label for="<?php echo esc_attr( $this->get_field_id( 'show_register' ) ); ?>"><?php esc_html_e( 'Show Register link', 'ct-theme' ); ?></label>	
				<br />
				<input id="<?php echo esc_attr( $this->get_field_id( 'show_forgotten_password' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_forgotten_password' ) ); ?>" type="checkbox" value="1" <?php if( esc_attr( $show_forgotten_password ) ) echo "checked='checked'" ?> />
				<label for="<?php echo esc_attr( $this->get_field_id( 'show_forgotten_password' ) ); ?>"><?php esc_html_e( 'Show Forgotten Password link', 'ct-theme' ); ?></label>	
			</p>
		<?php
	}
}
