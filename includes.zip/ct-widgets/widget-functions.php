<?php
/**
 * Theme widgets and sidebars.
 *
 * @package ct-theme
 * @author Cod3TURK Team
 * @link http://cod3turk.com
 */


/* ---------------------------------------------------------------------------
 * Widgets | Add
 * --------------------------------------------------------------------------- */
function ct_theme_register_widget()
{
	register_widget('ct_theme_Flickr_Widget');			// Flickr
	register_widget('ct_theme_Login_Widget');			// Login
	register_widget('ct_theme_Menu_Widget');				// Menu
	register_widget('ct_theme_Recent_Comments_Widget');	// Comments
	register_widget('ct_theme_Recent_Posts_Widget');		// Posts
	register_widget('ct_theme_Tag_Cloud_Widget');		// Tags
}
add_action('widgets_init','ct_theme_register_widget');


/* ---------------------------------------------------------------------------
 * Sidebar | Add
 * --------------------------------------------------------------------------- */
function ct_theme_register_sidebars() {

	// custom sidebars -------------------------------------------------------
	$sidebars = ct_theme_opts_get( 'sidebars' );
	if(is_array($sidebars))
	{
		foreach ($sidebars as $sidebar)
		{	
			register_sidebar( array (
				'name' 			=> $sidebar,
				'id' 			=> 'sidebar-'. str_replace("+", "-", urlencode(strtolower($sidebar))),
				'description'	=> esc_html__('Custom sidebar created in Theme Options.','ct-theme'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' 	=> '</aside>',
				'before_title' 	=> '<h3>',
				'after_title' 	=> '</h3>',
			));
		}	
	}
	
	
	// sidebar default  ----------------------------------------------------------
		for ($i = 1; $i <= 4; $i++)
		{
			register_sidebar(array(
				'name' 			=> esc_html__('Sidebar Default','ct-theme') .' | #'.$i,
				'id' 			=> 'top-area-'.$i,
				'description'	=> esc_html__('Appears in the Sidebar Default right or left section of the site.','ct-theme'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' 	=> '</aside>',
				'before_title' 	=> '<h4>',
				'after_title' 	=> '</h4>',
			));
		}
		
	
}
add_action( 'init', 'ct_theme_register_sidebars' );

